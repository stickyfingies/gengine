glslangValidator -V cube.vert.glsl -o cube.vert.spv
glslangValidator -V cube.frag.glsl -o cube.frag.spv
